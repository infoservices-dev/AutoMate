import { LightningElement, track } from 'lwc';
import invokePrompt from '@salesforce/apex/PromptUtils.invokePrompt';
import SendSearchQuery from '@salesforce/apex/ElasticSearch_Controller.SendSearchQuery';
import SendAutoResponse from '@salesforce/apex/ElasticSearch_Controller.SendAutoResponse';
import getAlternateResponses from '@salesforce/apex/ElasticSearch_Controller.getAlternateResponses';

export default class UserManualSearch extends LightningElement {
    @track searchQuery = '';
    @track searchResults='';
    @track alternateResponses=[];
    @track content='';
    @track suggestions = [];
    @track searchTerm = '';

    handleInputChange(event) {
        this.searchQuery = event.target.value;
        this.searchTerm = event.target.value;

        if (this.searchTerm.length > 1) {
            // Call Apex to fetch suggestions
            SendAutoResponse({ searchString: this.searchTerm })
                .then((result) => {
                    this.suggestions = result;
                })
                .catch((error) => {
                    console.error('Error fetching suggestions:', error);
                    this.suggestions = [];
                });
        } else {
            this.suggestions = [];
        }
    }

    handleSuggestionClick()
    {
        this.searchQuery = event.target.dataset.value;
        this.suggestions = [];
    }
    

    handleToggleSection(event) {
        this.activeSectionMessage =
            'Open section name:  ' + event.detail.openSections;
           
    }

    handleSearch() {

        console.log(this.searchQuery);
        if (this.searchQuery) {
        
                
                SendSearchQuery({ query: this.searchQuery })
                .then((result) => {
                   this.searchResults = result; // Store the response
                   console.log('Apex content:', this.searchResults);
               })
               .catch((error) => {
                   console.error('Error:', error); // Handle any errors
               });

               getAlternateResponses({query : this.searchQuery})
               .then((result) => {
                  this.alternateResponses = result; // Store the response
                  console.log('Alternate responses', this.alternateResponses);
              })
              .catch((error) => {
                  console.error('Error:', error); // Handle any errors
              });
              // this.template.querySelector('.myClass').innerHTML =  this.content;
               // this.searchResults =  resp; // Beautify JSON response
           
            }
         else {
            this.searchResults = 'Please enter a search query.';
        }
    }
}